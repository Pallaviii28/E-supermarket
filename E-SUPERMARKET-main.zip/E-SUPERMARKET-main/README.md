# E-SUPERMARKET

GROUP MEMBERS:
     DISHA BENDALE,
     DHRUVI HARIA,
     PALLAVI TAMBE
     
DECRIPTION:
The Supermarket Management System is a project that deals with supermarket automation and it includes both purchasing a selling of items. 
This project is designed with a goal to making the existing system more informative, reliable, fast and easier. There are many reasons for the starting of the project because in the selling of items through the manual system of salesperson faces a lot of inefficiencies. 
It requires handling of large record books that consist of both irrelevant and important information’s thus making it difficult to find out the required information as per necessity.
